# COMP-360-Group-3
Goal - Use RNG to simualte procedural genration 

Tasks: 

Program peaks point generation - Kabir

Program lighting + Camera - Andrea

Program Textures - Kirat 

Program Tesalation From peaks - Oscar

Implement code and bring everything together - Prasoon 
